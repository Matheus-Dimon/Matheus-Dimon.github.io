function entrar() {
    document.getElementById("but").innerHTML = "Seja bem vindo";
}
function sair() {
    document.getElementById("but").innerHTML = "Entrar";
}

